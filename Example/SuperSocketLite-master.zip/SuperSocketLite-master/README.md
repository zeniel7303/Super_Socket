# SuperSocketLite
- SuperSocket 1.6 버전의 .NET Core 포팅
- .NET 5 지원  
      
	  
# 사용 사례
SuperSocket은 .NET 플랫폼에서 인기 있는 오픈 소스 네트워크 라이브러리이지만, SuperSocket을 수정한 SuperSocketLite는 실 사용 사례가 많지는 않습니다.  
현재 SuperSocketLite를 사용한 게임은 제가 아는한은 제가 근무 중인 게임 회사에서 몇개의 모바일 게임에 사용되고 있습니다. 
혹시 SuperSocketLite을 사용하고 있다면 [여기](https://github.com/jacking75/SuperSocketLite/discussions/19)에 언제라도 알려주시기 부탁합니다^^  